Original scene sources. Requires Manim Community, FFmpeg and LaTeX for attention.
Render: python render_manim.py spec.json -o new.mp4 --python /path/to/manim-env/bin/python
Presentation timing is illustrative.
